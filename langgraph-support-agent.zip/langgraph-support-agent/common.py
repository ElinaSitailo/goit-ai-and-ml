"""Спільний мінімум для всіх ноутбуків: модель, корпус, ретривер, відмальовування графа.

Провайдер змінюється лише змінними середовища (див. .env.example):
    MODEL=google_genai:gemini-3.5-flash-lite   або  openai:gpt-4.1-mini, anthropic:claude-haiku-4-5 ...
    EMBEDDINGS_MODEL=google_genai:gemini-embedding-001   або  openai:text-embedding-3-small ...
"""

import os
import warnings
from pathlib import Path

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain.embeddings import init_embeddings
from langchain_core.documents import Document
from langchain_core.rate_limiters import InMemoryRateLimiter
from langchain_core.vectorstores import InMemoryVectorStore

load_dotenv(Path(__file__).parent / ".env")
# Нові моделі Gemini ігнорують temperature і попереджають про це при кожному виклику - глушимо шум у виводі.
warnings.filterwarnings("ignore", message=".*fixed sampling defaults.*")

CORPUS_DIR = Path(__file__).parent / "corpus"


def get_llm(model: str | None = None):
    """Чат-модель за рядком "провайдер:модель". LLM_RPM обмежує частоту запитів (безкоштовні тарифи)."""
    rpm = float(os.getenv("LLM_RPM", "0"))
    limiter = InMemoryRateLimiter(requests_per_second=rpm / 60, max_bucket_size=1) if rpm else None
    return init_chat_model(
        model or os.getenv("MODEL", "google_genai:gemini-3.5-flash-lite"),
        temperature=0,
        rate_limiter=limiter,
    )


def load_corpus() -> list[Document]:
    """Кожен розділ "## ..." кожного markdown-файлу - окремий чанк. Для маленької бази цього достатньо."""
    docs = []
    for path in sorted(CORPUS_DIR.glob("*.md")):
        title, *sections = path.read_text(encoding="utf-8").split("\n## ")
        for section in sections:
            docs.append(Document(page_content=f"{title.strip()}\n## {section.strip()}", metadata={"source": path.name}))
    return docs


def get_retriever(k: int = 3):
    """In-memory векторне сховище: ембединги обчислюються при кожному запуску, нічого не зберігається на диск."""
    embeddings = init_embeddings(os.getenv("EMBEDDINGS_MODEL", "google_genai:gemini-embedding-001"))
    store = InMemoryVectorStore.from_documents(load_corpus(), embeddings)
    return store.as_retriever(search_kwargs={"k": k})


def show_graph(graph):
    """PNG через mermaid.ink (потрібен інтернет); без мережі - друкуємо Mermaid-текст."""
    from IPython.display import Image, display

    try:
        display(Image(graph.get_graph().draw_mermaid_png()))
    except Exception:
        print(graph.get_graph().draw_mermaid())
