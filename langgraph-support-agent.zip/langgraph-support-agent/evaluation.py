"""Збір трейсів для eval: проганяємо агента по датасету й записуємо, що робив кожен вузол.

Трейс зберігається в JSON, тож метрики можна рахувати й перераховувати без жодного виклику LLM.
"""

import json
import time
import uuid
from pathlib import Path

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import HumanMessage

EVALS_DIR = Path(__file__).parent / "evals"


def load_dataset() -> list[dict]:
    return json.loads((EVALS_DIR / "dataset.json").read_text(encoding="utf-8"))


class LLMCounter(BaseCallbackHandler):
    """Рахує виклики моделі й токени за один прогін графа."""

    def __init__(self):
        self.calls, self.input_tokens, self.output_tokens = 0, 0, 0

    def on_llm_end(self, response, **kwargs):
        for generations in response.generations:
            for generation in generations:
                self.calls += 1
                usage = getattr(getattr(generation, "message", None), "usage_metadata", None) or {}
                self.input_tokens += usage.get("input_tokens", 0)
                self.output_tokens += usage.get("output_tokens", 0)


def run_case(graph, case: dict) -> dict:
    """Один прогін: шлях по графу, що знайшов і залишив пошук на кожній спробі, відповідь, ціна."""
    counter = LLMCounter()
    config = {"configurable": {"thread_id": str(uuid.uuid4())}, "callbacks": [counter]}
    trace = {"id": case["id"], "path": [], "retrieved": [], "kept": [], "queries": [],
             "intent": None, "order_id": None, "draft": None, "grounded": None, "answer": "", "paused": None}
    started = time.perf_counter()
    for step in graph.stream({"messages": [HumanMessage(case["question"])]}, config, stream_mode="updates"):
        for node, update in step.items():
            if node == "__interrupt__":
                trace["paused"] = update[0].value
                continue
            trace["path"].append(node)
            update = update or {}
            if node == "route":
                trace["intent"], trace["order_id"] = update["intent"], update["order_id"]
            elif node == "retrieve":
                trace["retrieved"].append([d.metadata["source"] for d in update["documents"]])
            elif node == "grade_documents":
                trace["kept"].append([d.metadata["source"] for d in update["documents"]])
            elif node == "rewrite_query":
                trace["queries"].append(update["query"])
            elif node == "generate":
                trace["draft"] = update["answer"]
            elif node == "check_grounding":
                trace["grounded"] = update["grounded"]
            if "answer" in update and update["answer"]:
                trace["answer"] = update["answer"]
    trace.update(seconds=round(time.perf_counter() - started, 1), llm_calls=counter.calls,
                 input_tokens=counter.input_tokens, output_tokens=counter.output_tokens)
    return trace


def collect(graph, dataset: list[dict], name: str, rerun: bool = False) -> list[dict]:
    """Повертає трейси з evals/runs_<name>.json; проганяє агента, лише якщо файлу немає або rerun=True."""
    path = EVALS_DIR / f"runs_{name}.json"
    if path.exists() and not rerun:
        print(f"Завантажено збережені трейси: {path.name}")
        return json.loads(path.read_text(encoding="utf-8"))
    traces = []
    for case in dataset:
        traces.append(run_case(graph, case))
        print(f"{case['id']}: {traces[-1]['seconds']} с, викликів LLM: {traces[-1]['llm_calls']}")
    path.write_text(json.dumps(traces, ensure_ascii=False, indent=1), encoding="utf-8")
    return traces
