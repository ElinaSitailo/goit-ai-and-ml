"""Агент з етапу 3 (03_actions.ipynb) одним модулем, щоб ноутбуки 05-06 імпортували його, а не копіювали.

Логіка та промпти ті самі. Єдина зміна: ліміт переписувань передається в build_graph(max_attempts=...),
щоб порівнювати конфігурації в eval. Так само передається промпт генерації (generate_prompt=...),
щоб у 05_metrics перевірити виправлення GENERATE_PROMPT_V2.
"""

from typing import Annotated, Literal, TypedDict

from langchain_core.documents import Document
from langchain_core.messages import AIMessage, AnyMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from common import get_llm, get_retriever

llm = get_llm()
retriever = get_retriever(k=3)


class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    question: str
    query: str
    documents: list[Document]
    attempts: int
    grounded: bool
    answer: str
    intent: str
    order_id: str | None
    reason: str | None
    approved: bool


class Grade(BaseModel):
    """Оцінка релевантності фрагмента бази знань питанню клієнта."""
    relevant: Literal["yes", "no"] = Field(description="yes - якщо фрагмент містить інформацію для відповіді на питання")


class Grounded(BaseModel):
    """Перевірка, що відповідь спирається на фрагменти бази знань."""
    grounded: Literal["yes", "no"] = Field(description="yes - якщо кожне твердження відповіді підтверджується фрагментами")


class Route(BaseModel):
    """Намір клієнта в останньому повідомленні."""
    intent: Literal["question", "refund"] = Field(description="refund - клієнт просить оформити повернення; question - будь-яке інше питання")
    order_id: str | None = Field(default=None, description="номер замовлення у форматі A-1234, якщо він є десь у діалозі")
    reason: str | None = Field(default=None, description="причина повернення, якщо клієнт її назвав")


grader = llm.with_structured_output(Grade)
grounding_checker = llm.with_structured_output(Grounded)
router = llm.with_structured_output(Route)

GRADE_PROMPT = "Питання клієнта: {question}\n\nФрагмент бази знань:\n{doc}\n\nЧи містить фрагмент інформацію, потрібну для відповіді на питання?"
REWRITE_PROMPT = """Перепиши питання клієнта на короткий пошуковий запит до бази знань інтернет-магазину
(розділи: повернення, доставка, оплата, гарантія, замовлення, контакти).
Питання: {question}
Попередній запит, за яким нічого не знайшлося: {query}
Поверни лише новий запит, без пояснень."""
GENERATE_PROMPT = """Ти — асистент підтримки інтернет-магазину «ЇжакМаркет».
Відповідай ЛИШЕ на основі наведених нижче фрагментів бази знань. Не додавай фактів, яких у них немає.
Якщо у фрагментах немає відповіді на питання, відповідай рівно: НЕМАЄ ВІДПОВІДІ

Фрагменти бази знань:
{context}

Питання клієнта: {question}"""
# Виправлення за результатами 05_metrics: відповідь «ні» і відповідь на частину питання - теж відповіді
GENERATE_PROMPT_V2 = """Ти — асистент підтримки інтернет-магазину «ЇжакМаркет».
Відповідай ЛИШЕ на основі наведених нижче фрагментів бази знань. Не додавай фактів, яких у них немає.
Якщо з фрагментів випливає відповідь «ні» (послуга не надається, товар не можна повернути тощо), це теж відповідь: дай її.
Якщо питання складається з кількох частин, відповідай на кожну.
Відповідай рівно НЕМАЄ ВІДПОВІДІ, лише якщо фрагменти не містять інформації для відповіді.

Фрагменти бази знань:
{context}

Питання клієнта: {question}"""
GROUNDING_PROMPT = "Фрагменти бази знань:\n{context}\n\nВідповідь асистента:\n{answer}\n\nЧи підтверджується КОЖНЕ твердження відповіді фрагментами?"
ROUTE_PROMPT = "Ти — маршрутизатор підтримки інтернет-магазину. За діалогом визнач, чого хоче клієнт в ОСТАННЬОМУ повідомленні."
NO_ANSWER = "НЕМАЄ ВІДПОВІДІ"
FALLBACK = "На жаль, я не знайшов відповіді в базі знань. Передаю ваше питання оператору — він зв'яжеться з вами найближчим часом."
ASK_ORDER_ID = "Щоб оформити повернення, назвіть, будь ласка, номер замовлення (формат A-1234)."


@tool
def issue_refund(order_id: str, reason: str) -> str:
    """Оформити повернення коштів за замовленням клієнта."""
    return f"Повернення за замовленням {order_id} оформлено (причина: {reason}). Кур'єр забере товар протягом 3 робочих днів."


def route(state: State) -> dict:
    decision = router.invoke([SystemMessage(ROUTE_PROMPT), *state["messages"]])
    question = state["messages"][-1].content
    return {
        "intent": decision.intent, "order_id": decision.order_id, "reason": decision.reason,
        # скидання полів минулої репліки: checkpointer зберігає їх між викликами
        "question": question, "query": question, "attempts": 0, "documents": [], "answer": "",
    }


def retrieve(state: State) -> dict:
    return {"documents": retriever.invoke(state["query"])}


def grade_documents(state: State) -> dict:
    prompts = [GRADE_PROMPT.format(question=state["question"], doc=doc.page_content) for doc in state["documents"]]
    grades = grader.batch(prompts)
    return {"documents": [doc for doc, g in zip(state["documents"], grades) if g.relevant == "yes"]}


def rewrite_query(state: State) -> dict:
    message = llm.invoke(REWRITE_PROMPT.format(question=state["question"], query=state["query"]))
    return {"query": message.text.strip(), "attempts": state["attempts"] + 1}


def check_grounding(state: State) -> dict:
    if NO_ANSWER in state["answer"]:
        return {"grounded": False}
    context = "\n\n".join(doc.page_content for doc in state["documents"])
    result = grounding_checker.invoke(GROUNDING_PROMPT.format(context=context, answer=state["answer"]))
    return {"grounded": result.grounded == "yes"}


def fallback(state: State) -> dict:
    return {"answer": FALLBACK}


def ask_order_id(state: State) -> dict:
    return {"answer": ASK_ORDER_ID}


def approve_refund(state: State) -> dict:
    decision = interrupt({"action": "issue_refund", "order_id": state["order_id"], "reason": state["reason"]})
    if decision == "yes":
        return {"approved": True}
    return {"approved": False, "answer": "Добре, повернення не оформлюю. Чим ще можу допомогти?"}


def do_refund(state: State) -> dict:
    return {"answer": issue_refund.invoke({"order_id": state["order_id"], "reason": state["reason"] or "не вказана"})}


def finish(state: State) -> dict:
    return {"messages": [AIMessage(state["answer"])]}


def route_by_intent(state: State) -> Literal["retrieve", "ask_order_id", "approve_refund"]:
    if state["intent"] == "question":
        return "retrieve"
    return "approve_refund" if state["order_id"] else "ask_order_id"


def route_after_check(state: State) -> Literal["finish", "fallback"]:
    return "finish" if state["grounded"] else "fallback"


def route_after_approval(state: State) -> Literal["do_refund", "finish"]:
    return "do_refund" if state["approved"] else "finish"


def build_graph(max_attempts: int = 2, generate_prompt: str = GENERATE_PROMPT):
    def generate(state: State) -> dict:
        context = "\n\n".join(doc.page_content for doc in state["documents"])
        message = llm.invoke(generate_prompt.format(context=context, question=state["question"]))
        return {"answer": message.text}

    def route_after_grade(state: State) -> Literal["generate", "rewrite_query", "fallback"]:
        if state["documents"]:
            return "generate"
        return "rewrite_query" if state["attempts"] < max_attempts else "fallback"

    builder = StateGraph(State)
    for node in [route, retrieve, grade_documents, rewrite_query, generate, check_grounding, fallback,
                 ask_order_id, approve_refund, do_refund, finish]:
        builder.add_node(node.__name__, node)

    builder.add_edge(START, "route")
    builder.add_conditional_edges("route", route_by_intent)
    builder.add_edge("retrieve", "grade_documents")
    builder.add_conditional_edges("grade_documents", route_after_grade)
    builder.add_edge("rewrite_query", "retrieve")
    builder.add_edge("generate", "check_grounding")
    builder.add_conditional_edges("check_grounding", route_after_check)
    builder.add_edge("fallback", "finish")
    builder.add_edge("ask_order_id", "finish")
    builder.add_conditional_edges("approve_refund", route_after_approval)
    builder.add_edge("do_refund", "finish")
    builder.add_edge("finish", END)
    return builder.compile(checkpointer=InMemorySaver())
