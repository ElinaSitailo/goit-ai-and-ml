# Архітектура агента підтримки (фінальний граф, етапи 3-4)

## Граф

Згенеровано `graph.get_graph().draw_mermaid()`; пунктир - умовні ребра.

```mermaid
---
config:
  flowchart:
    curve: linear
---
graph TD;
	__start__([<p>__start__</p>]):::first
	route(route)
	retrieve(retrieve)
	grade_documents(grade_documents)
	rewrite_query(rewrite_query)
	generate(generate)
	check_grounding(check_grounding)
	fallback(fallback)
	ask_order_id(ask_order_id)
	approve_refund(approve_refund)
	do_refund(do_refund)
	finish(finish)
	__end__([<p>__end__</p>]):::last
	__start__ --> route;
	approve_refund -.-> do_refund;
	approve_refund -.-> finish;
	ask_order_id --> finish;
	check_grounding -.-> fallback;
	check_grounding -.-> finish;
	do_refund --> finish;
	fallback --> finish;
	generate --> check_grounding;
	grade_documents -.-> fallback;
	grade_documents -.-> generate;
	grade_documents -.-> rewrite_query;
	retrieve --> grade_documents;
	rewrite_query --> retrieve;
	route -.-> approve_refund;
	route -.-> ask_order_id;
	route -.-> retrieve;
	finish --> __end__;
	classDef default fill:#f2f0ff,line-height:1.2
	classDef first fill-opacity:0
	classDef last fill:#bfb6fc
```

## State

| Поле | Тип | Хто пише | Хто читає | Reducer |
|---|---|---|---|---|
| `messages` | `list[AnyMessage]` | вхід (`HumanMessage`), `finish` | `route` | `add_messages` (дописує) |
| `question` | `str` | `route` | `grade_documents`, `rewrite_query`, `generate` | - |
| `query` | `str` | `route`, `rewrite_query` | `retrieve`, `rewrite_query` | - |
| `documents` | `list[Document]` | `route` (скидання), `retrieve`, `grade_documents` | `grade_documents`, `generate`, `check_grounding`, роутер після grade | - |
| `attempts` | `int` | `route` (скидання в 0), `rewrite_query` (+1) | `rewrite_query`, роутер після grade | - |
| `grounded` | `bool` | `check_grounding` | роутер після check | - |
| `answer` | `str` | `route` (скидання), `generate`, `fallback`, `ask_order_id`, `approve_refund` (відмова), `do_refund` | `check_grounding`, `finish` | - |
| `intent` | `str` | `route` | роутер після route | - |
| `order_id`, `reason` | `str \| None` | `route` | `approve_refund`, `do_refund`, роутер після route | - |
| `approved` | `bool` | `approve_refund` | роутер після approve | - |

## Вузли

| Вузол | Що робить | Читає → пише | LLM |
|---|---|---|---|
| `route` | визначає намір за всією історією, витягує номер замовлення, скидає поля попередньої репліки | `messages` → `intent`, `order_id`, `reason`, `question`, `query`, `attempts`, `documents`, `answer` | так (structured `Route`) |
| `retrieve` | top-3 фрагменти з in-memory векторного сховища | `query` → `documents` | ні (ембединг запиту) |
| `grade_documents` | залишає лише релевантні фрагменти, оцінювання паралельно через `.batch()` | `question`, `documents` → `documents` | так, по виклику на фрагмент (structured `Grade`) |
| `rewrite_query` | переформульовує пошуковий запит, збільшує лічильник | `question`, `query`, `attempts` → `query`, `attempts` | так |
| `generate` | відповідь строго за фрагментами або маркер `НЕМАЄ ВІДПОВІДІ` | `question`, `documents` → `answer` | так |
| `check_grounding` | перевіряє, що кожне твердження відповіді підтверджене фрагментами | `answer`, `documents` → `grounded` | так (structured `Grounded`), крім випадку `НЕМАЄ ВІДПОВІДІ` |
| `fallback` | фіксована чесна відмова «передаю оператору» | → `answer` | ні |
| `ask_order_id` | просить номер замовлення | → `answer` | ні |
| `approve_refund` | `interrupt()` - пауза до рішення людини | `order_id`, `reason` → `approved`, `answer` | ні |
| `do_refund` | викликає tool `issue_refund` | `order_id`, `reason` → `answer` | ні |
| `finish` | дописує відповідь в історію | `answer` → `messages` | ні |

## Умовні ребра

| Звідки | Умова | Куди |
|---|---|---|
| `route` | `intent == "question"` | `retrieve` |
| `route` | повернення, `order_id` відомий | `approve_refund` |
| `route` | повернення, `order_id` немає | `ask_order_id` |
| `grade_documents` | лишилися релевантні фрагменти | `generate` |
| `grade_documents` | порожньо і `attempts < 2` | `rewrite_query` (→ `retrieve`, цикл) |
| `grade_documents` | порожньо і `attempts >= 2` | `fallback` |
| `check_grounding` | `grounded` | `finish` |
| `check_grounding` | не `grounded` (зокрема `НЕМАЄ ВІДПОВІДІ`) | `fallback` |
| `approve_refund` | `approved` | `do_refund` |
| `approve_refund` | відхилено | `finish` |

## Ключові рішення і чому

1. **Явний граф замість ReAct-агента з `bind_tools`.** Шлях запиту передбачуваний і видимий на картинці; для підтримки з грошима це важливіше за гнучкість. Модель лише класифікує, а вирішує граф.
2. **Повернення викликається з вузла, а не моделлю.** `issue_refund` - справжній `@tool` (схема готова для `bind_tools`), але виконується лише в `do_refund`, куди немає шляху в обхід `approve_refund`. Безпеку забезпечено структурою, а не промптом.
3. **Дві перевірки проти галюцинацій**: фільтр релевантності до генерації (дешевий, відсікає більшість випадків поза базою) і перевірка обґрунтованості після (ловить вигадку всередині «правильного» контексту). Плюс машинно-перевірюваний маркер `НЕМАЄ ВІДПОВІДІ`.
4. **Лічильник спроб у State + `recursion_limit`.** Лічильник - бізнес-правило зі зрозумілим клієнтові fallback; `recursion_limit` - аварійна зупинка на випадок помилки в логіці роутера.
5. **Fallback і службові відповіді без LLM.** Відмова, прохання номера та скасування - фіксовані рядки: їх погоджують з бізнесом, вони безкоштовні й детерміновані (за ними працює eval).
6. **Роутери - чисті функції**, уся робота з LLM - у вузлах. Роутер легко прочитати й протестувати, а кожне рішення моделі збережене в State і видно в трейсі.
7. **`route` скидає поля попередньої репліки.** Checkpointer зберігає весь State треду, а не лише `messages`; без скидання `attempts` і `documents` з попереднього питання ламали б нове.

## Заготовлені поломки для демо

| Поломка | Як відтворити | Як лагодиться |
|---|---|---|
| **Вигадка поза базою** | `01_baseline`: питання «Скільки бонусних балів я отримаю за замовлення на 5000 гривень?» - агент називає конкретне число балів, якого немає в базі | `02_reliability`: `grade_documents` + умовне ребро → `fallback`; суворий промпт з `НЕМАЄ ВІДПОВІДІ`; `check_grounding` |
| **Зациклення rewrite** | `02_reliability`: роутер `route_without_limit` без перевірки `attempts` - на питанні поза базою цикл `retrieve → grade → rewrite` не закінчується | лічильник `attempts` і `MAX_ATTEMPTS = 2` у роутері; страховка - `config={"recursion_limit": N}` → `GraphRecursionError` |
| **Повернення без підтвердження** | у `03_actions` замінити `route → approve_refund` на `route → do_refund` у `route_by_intent` (або прибрати `interrupt` з `approve_refund`) - гроші «повертаються» одразу після фрази клієнта | `interrupt()` в окремому вузлі перед `do_refund`; checkpointer (без нього `interrupt` не працює); відновлення `Command(resume="yes"/"no")` |

## Відповідність чистому API

| Що я робив вручну | Що це в LangGraph |
|---|---|
| словник з даними запиту, який передаю між функціями | `State` (`TypedDict`) |
| функції `retrieve()`, `generate()` | вузли `add_node` |
| послідовні виклики функцій | ребра `add_edge` |
| `if/elif` після кроку | умовне ребро `add_conditional_edges` + функція-роутер |
| `while attempts < 2:` | цикл `rewrite_query → retrieve` + лічильник у State |
| захист `for _ in range(MAX_STEPS)` | `recursion_limit` у config |
| `history.append(...)` | поле з reducer'ом `add_messages` |
| `histories[user_id]` | checkpointer (`InMemorySaver`) + `thread_id` |
| `input("Підтвердити? ")` | `interrupt()` + `Command(resume=...)` |
| `json.loads(відповідь)` + валідація | `llm.with_structured_output(PydanticModel)` |
| `print()` на кожному кроці | `stream(stream_mode="updates")`, трейси LangSmith |
